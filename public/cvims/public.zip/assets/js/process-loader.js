class ProcessLoader{
    showProcessLoader(){
        return  $( "#save-loader" ).show();
    }

    hideProcessLoader(){
        return  $( "#save-loader" ).hide();
    }
}
